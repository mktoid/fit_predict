Запуск приложения:

streamlit run app.py